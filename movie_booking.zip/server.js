const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();

// Middleware
app.use(bodyParser.json());

// Serve static files from the 'public' directory
app.use(express.static(path.join(__dirname, 'public')));

// Connect to MongoDB
const dbURI = 'mongodb://localhost:27017/my-node-project'; // Replace 'my-node-project' with your database name
mongoose.connect(dbURI, { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => console.log('MongoDB connected'))
    .catch(err => {
        console.error('MongoDB connection error:', err.message);
        process.exit(1); // Exit if database connection fails
    });

// Movie Schema
const bookingSchema = new mongoose.Schema({
    movie: { type: String, required: true },
    date: { type: String, required: true },
    theater: { type: String, required: true },
    seats: { type: [Number], required: true },
    price: { type: Number, required: true }
});

const Booking = mongoose.model('Booking', bookingSchema);

// Routes
app.post('/api/book_ticket', async (req, res) => {
    const { movie, date, theater, seats, price } = req.body;

    // Input validation
    if (!movie || !date || !theater || !seats || !price) {
        console.error('Validation Error: Missing fields');
        return res.status(400).json({ error: 'All fields are required' });
    }

    try {
        const newBooking = new Booking({ movie, date, theater, seats, price });
        await newBooking.save();
        console.log('Booking successful:', newBooking);
        return res.status(201).json({ message: 'Booking confirmed' });
    } catch (err) {
        console.error('Error during booking:', err.message);
        return res.status(500).json({ error: 'Booking failed', details: err.message });
    }
});


// Start Server
const PORT = process.env.PORT || 5500;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
